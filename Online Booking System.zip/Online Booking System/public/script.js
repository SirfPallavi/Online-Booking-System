// Hotel Booking System JavaScript

// Room prices configuration
const roomPrices = {
    standard: 99,
    deluxe: 149,
    suite: 299
};

// DOM elements
const bookingForm = document.getElementById('bookingForm');
const checkInInput = document.getElementById('checkIn');
const checkOutInput = document.getElementById('checkOut');
const roomTypeSelect = document.getElementById('roomType');
const totalNightsSpan = document.getElementById('totalNights');
const roomRateSpan = document.getElementById('roomRate');
const totalAmountSpan = document.getElementById('totalAmount');
const confirmationModal = document.getElementById('confirmationModal');
const confirmationDetails = document.getElementById('confirmationDetails');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeDates();
    attachEventListeners();
    initializeRoomCards();
});

// Set minimum date to today
function initializeDates() {
    const today = new Date().toISOString().split('T')[0];
    checkInInput.min = today;
    checkOutInput.min = today;
}

// Attach event listeners
function attachEventListeners() {
    // Date change listeners
    checkInInput.addEventListener('change', handleDateChange);
    checkOutInput.addEventListener('change', handleDateChange);
    roomTypeSelect.addEventListener('change', calculateTotal);
    
    // Form submission
    bookingForm.addEventListener('submit', handleFormSubmission);
    
    // Modal close functionality
    const closeBtn = document.querySelector('.close');
    closeBtn.addEventListener('click', closeModal);
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === confirmationModal) {
            closeModal();
        }
    });
}

// Initialize room card interactions
function initializeRoomCards() {
    const roomCards = document.querySelectorAll('.room-card');
    roomCards.forEach(card => {
        card.addEventListener('click', function() {
            const roomType = this.dataset.room;
            selectRoom(roomType);
        });
    });
}

// Handle room selection from cards
function selectRoom(roomType) {
    roomTypeSelect.value = roomType;
    calculateTotal();
    scrollToBooking();
}

// Smooth scroll to booking section
function scrollToBooking() {
    document.getElementById('booking').scrollIntoView({
        behavior: 'smooth'
    });
}

// Handle date changes
function handleDateChange() {
    const checkIn = new Date(checkInInput.value);
    const checkOut = new Date(checkOutInput.value);
    
    // Ensure check-out is after check-in
    if (checkInInput.value && checkOut <= checkIn) {
        const nextDay = new Date(checkIn);
        nextDay.setDate(nextDay.getDate() + 1);
        checkOutInput.value = nextDay.toISOString().split('T')[0];
    }
    
    // Update minimum check-out date
    if (checkInInput.value) {
        const minCheckOut = new Date(checkIn);
        minCheckOut.setDate(minCheckOut.getDate() + 1);
        checkOutInput.min = minCheckOut.toISOString().split('T')[0];
    }
    
    calculateTotal();
}

// Calculate total cost
function calculateTotal() {
    const checkIn = checkInInput.value;
    const checkOut = checkOutInput.value;
    const roomType = roomTypeSelect.value;
    
    if (!checkIn || !checkOut || !roomType) {
        resetSummary();
        return;
    }
    
    // Calculate number of nights
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const timeDiff = checkOutDate.getTime() - checkInDate.getTime();
    const nights = Math.ceil(timeDiff / (1000 * 3600 * 24));
    
    if (nights <= 0) {
        resetSummary();
        return;
    }
    
    // Get room price
    const roomPrice = roomPrices[roomType];
    const totalAmount = nights * roomPrice;
    
    // Update summary
    totalNightsSpan.textContent = nights;
    roomRateSpan.textContent = `$${roomPrice}/night`;
    totalAmountSpan.textContent = `$${totalAmount}`;
}

// Reset booking summary
function resetSummary() {
    totalNightsSpan.textContent = '0';
    roomRateSpan.textContent = '$0/night';
    totalAmountSpan.textContent = '$0';
}

// Handle form submission
function handleFormSubmission(event) {
    event.preventDefault();
    
    // Validate form
    if (!validateForm()) {
        return;
    }
    
    // Get form data
    const formData = new FormData(bookingForm);
    const bookingData = Object.fromEntries(formData.entries());
    
    // Calculate booking details
    const checkIn = new Date(bookingData.checkIn);
    const checkOut = new Date(bookingData.checkOut);
    const nights = Math.ceil((checkOut - checkIn) / (1000 * 3600 * 24));
    const roomPrice = roomPrices[bookingData.roomType];
    const totalAmount = nights * roomPrice;
    
    // Generate booking ID
    const bookingId = generateBookingId();
    
    // Store booking (in a real app, this would be sent to a server)
    const booking = {
        id: bookingId,
        ...bookingData,
        nights: nights,
        roomPrice: roomPrice,
        totalAmount: totalAmount,
        bookingDate: new Date().toISOString()
    };
    
    // Save to memory (simulating database storage)
    saveBooking(booking);
    
    // Show confirmation
    showConfirmation(booking);
    
    // Reset form
    bookingForm.reset();
    resetSummary();
}

// Validate form
function validateForm() {
    const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'checkIn', 'checkOut', 'roomType', 'guests'];
    
    for (let field of requiredFields) {
        const element = document.getElementById(field);
        if (!element.value.trim()) {
            showError(`Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}`);
            element.focus();
            return false;
        }
    }
    
    // Validate email format
    const email = document.getElementById('email').value;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showError('Please enter a valid email address');
        document.getElementById('email').focus();
        return false;
    }
    
    // Validate dates
    const checkIn = new Date(document.getElementById('checkIn').value);
    const checkOut = new Date(document.getElementById('checkOut').value);
    
    if (checkOut <= checkIn) {
        showError('Check-out date must be after check-in date');
        document.getElementById('checkOut').focus();
        return false;
    }
    
    return true;
}

// Show error message
function showError(message) {
    alert(message); // In a real app, you'd use a more elegant error display
}

// Generate unique booking ID
function generateBookingId() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `BK${timestamp}${random}`;
}

// Save booking to memory (simulating database)
function saveBooking(booking) {
    let bookings = JSON.parse(localStorage.getItem('hotelBookings') || '[]');
    bookings.push(booking);
    localStorage.setItem('hotelBookings', JSON.stringify(bookings));
}

// Show confirmation modal
function showConfirmation(booking) {
    const checkInDate = new Date(booking.checkIn).toLocaleDateString();
    const checkOutDate = new Date(booking.checkOut).toLocaleDateString();
    const roomTypeName = getRoomTypeName(booking.roomType);
    
    confirmationDetails.innerHTML = `
        <div style="margin-bottom: 1rem;">
            <strong>Booking ID:</strong> ${booking.id}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Guest:</strong> ${booking.firstName} ${booking.lastName}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Email:</strong> ${booking.email}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Phone:</strong> ${booking.phone}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Check-in:</strong> ${checkInDate}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Check-out:</strong> ${checkOutDate}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Room Type:</strong> ${roomTypeName}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Guests:</strong> ${booking.guests}
        </div>
        <div style="margin-bottom: 1rem;">
            <strong>Nights:</strong> ${booking.nights}
        </div>
        <div style="margin-bottom: 1rem; padding-top: 1rem; border-top: 2px solid #667eea;">
            <strong>Total Amount:</strong> $${booking.totalAmount}
        </div>
        ${booking.specialRequests ? `
        <div style="margin-bottom: 1rem;">
            <strong>Special Requests:</strong> ${booking.specialRequests}
        </div>
        ` : ''}
        <div style="color: #28a745; font-weight: 600; text-align: center; margin-top: 1rem;">
            Your booking has been confirmed! You will receive a confirmation email shortly.
        </div>
    `;
    
    confirmationModal.style.display = 'block';
}

// Get room type display name
function getRoomTypeName(roomType) {
    const names = {
        standard: 'Standard Room',
        deluxe: 'Deluxe Room',
        suite: 'Executive Suite'
    };
    return names[roomType] || roomType;
}

// Close confirmation modal
function closeModal() {
    confirmationModal.style.display = 'none';
}

// Smooth scrolling for navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add loading state to form submission
function addLoadingState() {
    const submitBtn = document.querySelector('.submit-btn');
    const originalText = submitBtn.textContent;
    
    submitBtn.textContent = 'Processing...';
    submitBtn.disabled = true;
    
    // Simulate processing time
    setTimeout(() => {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }, 2000);
}

// Utility function to format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

// Add animation classes when elements come into view
function observeElements() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    });
    
    document.querySelectorAll('.room-card, .booking-form').forEach(el => {
        observer.observe(el);
    });
}

// Initialize animations when page loads
window.addEventListener('load', observeElements);