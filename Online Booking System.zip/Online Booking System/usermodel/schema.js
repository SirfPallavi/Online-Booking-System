// usermodel.js (or Booking.js)
const mongoose = require('mongoose');

mongoose.connect("mongodb://localhost:27017/RealEstate").then(() => {
  console.log("database connected");
});

const bookingSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true,
    trim: true
  },
  lastName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },
  phone: {
    type: String,
    required: true,
    trim: true
  },
  roomType: {
    type: String,
    required: true,
    enum: ['standard', 'deluxe', 'suite'] // match form values
  },
  numberOfGuests: {
    type: Number,
    required: true,
    min: 1
  },
  specialRequests: {
    type: String,
    default: ''
  },
  totalNights: {
    type: Number,
    required: true
  },
  roomRate: {
    type: Number,
    required: true
  },
  totalAmount: {
    type: Number,
    required: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Booking', bookingSchema);
